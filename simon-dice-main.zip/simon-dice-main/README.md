# simon-dice
Juego Simon Says en html, css y js creado en este tutorial: https://youtu.be/M9NzCWw1VzU

<img width="542" alt="Screen Shot 2021-09-18 at 00 22 33" src="https://user-images.githubusercontent.com/26985597/133870927-120e2bec-47ee-44a9-9a4e-6721d577be98.png">
